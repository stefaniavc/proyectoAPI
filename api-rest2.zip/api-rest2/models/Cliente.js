const{Schema, model} = require('mongoose');

const ClienteSchema= Schema ({
Nombre:{
 type: String,
 required: true,
 },
 Email:{
    type: String,
    required: true,
    },
    fechaCreacion:{
        type: Date,
        required: true,
    },
    fechaActualizacion:{
        type: Date,
        required: true,
    }

});
module.exports = module ( 'Cliente', ClienteSchema);
