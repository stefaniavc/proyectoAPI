const {Router }= require ('express');
const TipodeProyecto= require ('../TipodeProyecto');
const router = Router ();

router.get('/', async function(req, res){
    try{
         const tipos= await TipodeProyecto.find ();
         res.send (tipos);
    } catch (error) {
        console.log(error);
        res.send ('ocurrio un error');
    }
});

router.post('/', async function(req, res){
    try {
        let TipodeProyecto= new TipodeProyecto ();
        TipodeProyecto.nombre= req.body.nombre;
        TipodeProyecto.fechaCreacion= new Date();
        TipodeProyecto.fechaActualizacion = new Date();
        TipodeProyecto = await TipodeProyecto.save();
        res.send(TipodeProyecto);

    }catch(error){
        console.log(error);
        res.send('ocurrio un error');
    }
});

router.put('/:TipodeProyectoId', async function(req, res){
    try {
        let TipodeProyecto= await TipodeProyecto.findById(req.params.TipodeProyectoId);
        if(!TipodeProyecto){
            return res.send('no existe TipodeProyecto');
        }
        TipodeProyecto.nombre= req.body.nombre;
        TipodeProyecto.fechaActualizacion = new Date();
        TipodeProyecto = await TipodeProyecto.save();
        res.send(TipodeProyecto);

    }catch(error){
        console.log(error);
        res.send('ocurrio un error');
    }
});
module.exports=router;