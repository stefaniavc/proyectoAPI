const{Router} = require ( 'express');
const Proyecto = require('../Proyecto');
const router= Router();
//const Proyecto = require ('../Proyecto')

router.post( '/',async function (req, res){

try {
    console.log(req.body);

const existeProyecto= await Proyecto.findOne({Numero: req.body.Numero});
console.log('respuesta existe Proyecto', existeProyecto);
if (existeProyecto){
    return res.send('Numero ya existe');
}

    let Proyecto = new Proyecto ();
    Proyecto.Numero= req.body.Numero;
    Proyecto.Titulo= req.body.Titulo;
    Proyecto.FechadeIniciacion= new Date ();
    Proyecto.fechaCreacion= new Date ();
    Proyecto.fechaActualizacion= new Date ();
    Proyecto.FechadeEntrega= new Date ();
    Proyecto.Valor= req.body.Valor;
    Proyecto= await Proyecto.save();
    res.send(Proyecto);
    

} catch(error){
    console.log(error);
  res.send('ocurrio un error');
}


});

router.get( '/', function (req, res){
    res.send( 'hola mundo estoy en crear Proyecto GET');
 });
 
router.put( '/:ProyectoId', async function (req, res){
    try {
        console.log(req.body,req.params);

        let Proyecto= await Proyecto.findById(req.params.ProyectoId);
        if(!Proyecto){
            return res.send('Proyecto no existe');
        }
    
   const existeProyecto= await Proyecto
   .findOne({Titulo: req.body.Titulo, _id: {$ne: Proyecto._id}});
    console.log('respuesta existe Proyecto', existeProyecto);

    if (existeProyecto){
        return res.send('Titulo ya existe');
    }

Proyecto.Titulo= req.body.Titulo;
Proyecto.Numero=req.body.Numero;
Proyecto.FechadeIniciacion=req.body.FechadeIniciacion;
        
        Proyecto= await Proyecto.save();
        res.send(Proyecto);
        
    
    } catch(error){
        console.log(error);
      res.send('ocurrio un error');
    }
 });    
module.exports = router;