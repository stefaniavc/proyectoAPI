const {Router} = require ('express');

const router = Router ();
 
router.get ('/',function(req, res){
    res.send ('estoy desde Cliente GET')
});
router.post ('/',function(req, res){
    res.send ('estoy desde Cliente POST')
});
router.put ('/',function(req, res){
    res.send ('estoy desde Cliente PUT')
});
module.exports= router;
