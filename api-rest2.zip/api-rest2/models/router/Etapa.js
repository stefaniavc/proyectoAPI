const {Router} = require ('express');
const Etapa = require('../Etapa');
const Etapa= require ('../Etapa');


const router= Router ();

router.get('/', async function(req, res){
 try{
const tipos= await Etapa.find();
res.send(tipos);
 }catch(error){
    console.log(error);
    res.send('ocurrio un error');
 }
});

router.put('/:EtapaId', async function(req, res){
    try{
        let Etapa= await Etapa.findById(req.params.EtapaId);
        
        Etapa.nombre= req.body.nombre;
        Etapa.fechaCreacion= new Date();
        Etapa.fechaActualizacion= new Date();
        Etapa= await Etapa.save();
        res.send(Etapa);
        }catch (error){
            console.log(error);
            res.send('ocurrio un error');
        }
});
router.post('/',async function(req, res){
try{
let Etapa= new Etapa();

Etapa.nombre= req.body.nombre;
Etapa.fechaCreacion= new Date();
Etapa.fechaActualizacion= new Date();
Etapa= await Etapa.save();
res.send(Etapa);
}catch (error){
    console.log(error);
    res.send('ocurrio un error');
}
 });   
 module.exports = router;