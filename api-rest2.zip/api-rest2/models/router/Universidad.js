const {Router} = require('express');
const Universidad = require ('../Universidad');

const router = Router ();

router.get ('/', async function(req, res){
  try{
    const Universidad = await Universidad.find();
    res.send (Universidad);

  } catch (error){
    console.log(error);
    res.send('ocurrio un error')
  }

    
});
router.post('/', async function(req, res){
    try{
        let Universidad =new Universidad();
        Universidad.nombre= req.body.nombre;
        Universidad.Direccion= req.body.Direccion;
        Universidad.fechaCreacion= new Date();
        Universidad.fechaActualizacion= new Date();
        Universidad= await Universidad.save();
        res.send( Universidad);
    } catch (error) {
        console.log(error);
        res.send('ocurrio un error');
    }
});

router.put ('/:UniversidadId',async function(req, res){
    try{
        let Universidad = await Universidad.findById(req.params.UniversidadId);
        if (!Universidad){
            return res.send('Universidad no existe');
        }
        Universidad.nombre= req.body.nombre;
        Universidad.Direccion= req.body.Direccion;
        Universidad.fechaActualizacion= new Date();
        Universidad= await Universidad.save();
        res.send( Universidad);
    } catch (error) {
        console.log(error);
        res.send('ocurrio un error');
    }
});
module.exports =router;