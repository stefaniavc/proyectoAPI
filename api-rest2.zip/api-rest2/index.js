const express = require('express');
const {getConnection} = require ('./DB/conexion-mongo');

const app = express();
const port = 3000;

getConnection();
//Parseo json
app.use(express.json());

app.use('/Proyecto', require('./models/router/Proyecto'));
app.use('/TipodeProyecto', require('./models/router/TipodeProyecto'));
app.use('/Universidad', require('./models/router/Universidad'));
app.use('/Etapa', require('./models/router/Etapa'));
//app.use('/Cliente', require('./models/router/Cliente'));
 app.listen(port, () => {
    console.log('Example app listening on port ${port}')
 });